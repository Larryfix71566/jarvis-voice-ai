"""Pipeline construction and session runner (plan Phase 4 step 4.2, Phase 5 step 5.1).

Locked processor order (Phase 5):
    transport.input()
      -> VADProcessor(SileroVADAnalyzer)          # D-004: VAD is a processor in pipecat 1.4
      -> DeepgramFluxSTTService (flux-general-en) # should_interrupt=False; interruptions come from the turn-start strategy
      -> context_aggregator.user()
      -> OpenAILLMService
      -> TranscriptLogger
      -> ElevenLabsTTSService (eleven_flash_v2_5)
      -> transport.output()
      -> context_aggregator.assistant()

Three functions are registered on the LLM: delegate_task, set_voice, and
remember (reliable-memory plan D6). run_session() owns everything
per-connection so bot.py's entry shape never changes again.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

from pipecat.frames.frames import OutputTransportMessageUrgentFrame
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineTask
from pipecat.turns.user_start import MinWordsUserTurnStartStrategy
from pipecat.turns.user_turn_strategies import UserTurnStrategies

from jarvis.agents.base import load_sub_agents
from jarvis.agents.delegate import build_delegate_tool
from jarvis.bot.display import WeatherReportMerger, build_display_payload
from jarvis.bot.interruption import InterruptionNotifier
from jarvis.bot.memory_watcher import MemorySweepWatcher
from jarvis.bot.plan_watcher import PlanWatcher
from jarvis.bot.research_watcher import ResearchWatcher
from jarvis.bot.progress_watcher import ProgressWatcher, SpeakingStateTracker
from jarvis.bot.reminders_watcher import RemindersWatcher
from jarvis.bot.remember_tool import build_remember_tool
from jarvis.bot.transcript_log import TranscriptLogger, TranscriptObserver
from jarvis.bot.ui_control import build_ui_control_tool
from jarvis.bot.handoff_tools import (
    build_clear_clipboard_tool,
    build_read_clipboard_tool,
    build_show_commands_tool,
)
from jarvis.bot.screen_tool import build_list_screens_tool, build_view_screen_tool
from jarvis.bot.speaker_gate import (
    GateState,
    SpeakerTap,
    SpeakerVerifiedMinWordsTurnStartStrategy,
    TranscriptGate,
)
from jarvis.bot.voice_switch import (
    available_list,
    build_set_voice_tool,
    catalog_summary,
    load_voice_catalog,
    resolve_voice,
)
from jarvis import speaker
from jarvis.cli import bridge_settings_to_env
from jarvis.config import Settings, load_settings
from jarvis.db import run_migrations
from jarvis.logging_config import setup_logging
from jarvis.memory import (
    MEMORY_EXTRACTION_TIMEOUT_S,
    render_memory_context,
    update_memory_from_session,
)
from jarvis.prompts import (
    SUPERVISOR_PROMPT,
    HANDOFF_ADDENDUM,
    SCREEN_VISION_ADDENDUM,
    UI_CONTROL_ADDENDUM,
    VOICE_ADDENDUM,
    render_agent_catalog,
)
from jarvis.council import prune as prune_council
from jarvis.runlog import prune as prune_runlog
from jarvis.runlog import reconcile_orphaned_runs
from jarvis.skills.registry import REPO_ROOT, SkillRegistry

# Service imports are module-level names so tests can monkeypatch them.
# D-004: pipecat 1.4.0 class locations/settings classes differ from the
# plan's draft API (Flux under services.deepgram.flux.stt, ToolsSchema
# under adapters.schemas, FunctionSchema instead of raw OpenAI dicts,
# VAD as VADProcessor, interruptions via the turn-start strategy).
from pipecat.adapters.schemas.function_schema import FunctionSchema
from pipecat.adapters.schemas.tools_schema import ToolsSchema
from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.audio.vad.vad_analyzer import VADParams
from pipecat.processors.audio.vad_processor import VADProcessor
from pipecat.services.deepgram.flux.base import DeepgramFluxSTTSettings
from pipecat.services.deepgram.flux.stt import DeepgramFluxSTTService
from pipecat.services.elevenlabs.tts import (
    ElevenLabsTTSService,
    ElevenLabsTTSSettings,
)
from pipecat.services.openai.llm import OpenAILLMService
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import (
    LLMContextAggregatorPair,
    LLMUserAggregatorParams,
)

_logger = logging.getLogger(__name__)


@dataclass
class Runtime:
    """Per-session resources shared by the pipeline and event handlers."""

    settings: Settings
    registry: SkillRegistry
    session_id: str
    # Barge-in survival (Larry 2026-08-21: "me continuing to talk should
    # not kill existing work"): late-bound delivery hook for delegation
    # results whose voice turn was cancelled mid-flight. build_pipeline
    # hands this holder to build_delegate_tool; run_session fills in
    # "fn" (the inject_context closure) once the aggregators exist. A
    # dict rather than a Callable field because the hook cannot exist yet
    # at construction time — same late-binding reason RemindersWatcher
    # takes inject= at run_session level.
    late_delivery: dict = field(default_factory=dict)
    # Tier 2 (2026-08-21): the live TranscriptGate instance when the
    # speaker gate is active, else None. run_session hands it to
    # TranscriptObserver so persisted USER lines match what the LLM
    # actually received — a dropped speaker's words must not reach the
    # conversations table (the memory sweep folds it into memory).
    speaker_gate: Any = None


def bot_event_log(event: dict) -> None:
    """stdout agent-activity feed (Phase 4; UI feed arrives in Phase 6)."""
    if event.get("type") == "delegate_start":
        print(f"[AGENT] {event['display_name']} working: {event['task']!r}", flush=True)
    elif event.get("type") == "agent_tool":
        print(f"[AGENT] {event['display_name']} calling {event['tool']}…", flush=True)
    elif event.get("type") in ("agent_done", "delegate_done"):
        print(f"[AGENT] {event['display_name']} done", flush=True)


def make_agent_event_handler(transport: Any) -> Any:
    """Plan Phase 6 step 6.3: log agent events AND feed them to the UI.

    on_event callbacks are sync (agents/base.py EventCallback), so the async
    app-message send is scheduled on the running loop. Message shapes:
    {"type": "agent", "name", "display_name", "state": "working",
     "task": <delegated task>} on delegate_start;
    {"type": "agent", "name", "display_name", "state": "done",
     "ok": <bool>, "detail": <failure reason or "">} on delegate_done;
    {"type": "agent_tool", "name", "display_name", "tool"} while a
    specialist calls a tool; and {"type": "display", "display": <payload>}
    when a tool result is display-worthy (see jarvis/bot/display.py).
    The delegate_* pair owns the lifecycle the UI shows (one status card
    per delegation); agent_start/agent_done remain log-only so the UI
    never sees duplicate working/done messages.
    """

    # W5 (MORTIMER_WEATHER_FAHRENHEIT_AND_RADAR_PLAN.md) — one instance per
    # connection, keyed internally by run_id, pairing get_weather +
    # get_weather_radar tool results into a single display card. See
    # jarvis.bot.display.WeatherReportMerger's own docstring for the
    # merge semantics (never suppresses a lone result).
    weather_merger = WeatherReportMerger()

    def on_agent_event(event: dict) -> None:
        bot_event_log(event)
        etype = event.get("type")
        if etype == "agent_tool_result":
            # Activity ticker (Larry 2026-08-21, "like how claude displays
            # updates to current work"): every finished tool call becomes
            # one line on the run's Agents card — truthful by construction,
            # since ok comes from the same classify_tool_result verdict the
            # run log records, not from a model narrating itself. Sent for
            # EVERY result, before the display-worthiness check below,
            # which only decides whether a separate content payload opens.
            tool_name = str(event.get("tool") or "")
            activity_msg: dict[str, Any] = {
                "type": "agent_activity",
                "name": event.get("agent"),
                "run_id": event.get("run_id"),
                "tool": tool_name,
                "ok": bool(event.get("ok", True)),
                "latency_ms": int(event.get("latency_ms") or 0),
            }
            # G7 (MORTIMER_SESSION_GAPS_AND_SELFEDIT_CONVERGENCE_PLAN.md):
            # the Agents-tab card shows SubAgent.model (the developer's OWN
            # resolved model, e.g. Haiku or kimi-k3) — but the model doing
            # the actual self-edit WORK is a separate planner picked inside
            # the admin sidecar and only known once selfedit_start/status
            # returns. Both mcp_selfedit tools echo it back as
            # `planner_model` (see mcp_servers/mcp_selfedit/logic.py) — ride
            # it on the SAME per-tool-call channel already sent for every
            # result, rather than inventing a second message type.
            if tool_name in ("selfedit_start", "selfedit_status"):
                try:
                    parsed = json.loads(str(event.get("result") or "{}"))
                except (TypeError, ValueError):
                    parsed = {}
                planner_model = parsed.get("planner_model") if isinstance(parsed, dict) else None
                if isinstance(planner_model, str) and planner_model:
                    activity_msg["planner_model"] = planner_model
            try:
                asyncio.get_running_loop().create_task(
                    send_app_message(transport, activity_msg))
            except RuntimeError:
                pass  # no running loop (tests calling the handler directly)
            if tool_name in ("get_weather", "get_weather_radar"):
                # W5 — route through the merger instead of displaying each
                # tool's result on its own; offer() returns a payload only
                # once both halves are accounted for (or None while still
                # waiting on the pair — see WeatherReportMerger).
                payload = weather_merger.offer(
                    run_id=str(event.get("run_id") or ""),
                    agent=str(event.get("agent") or ""),
                    display_name=str(event.get("display_name") or ""),
                    tool=tool_name,
                    result_str=str(event.get("result") or ""),
                )
            else:
                payload = build_display_payload(
                    agent=str(event.get("agent") or ""),
                    display_name=str(event.get("display_name") or ""),
                    tool=tool_name,
                    arguments=event.get("arguments")
                    if isinstance(event.get("arguments"), dict) else {},
                    result_str=str(event.get("result") or ""),
                )
            if payload is None:
                return  # voice-only tool result, or still awaiting the pair
            # MORTIMER_AGENT_TRUST_PLAN.md D18: one INFO line whenever a
            # display payload is actually built, so MORTIMER_SIDE_DRAWER_
            # PLAN.md D36's surface routing (drawer vs. floating window)
            # is confirmable from logs alone, without a browser attached.
            _logger.info(
                "display_payload tool=%s surface=%s agent=%s kind=%s",
                event.get("tool"), payload.get("surface"),
                event.get("agent"), payload.get("kind"),
            )
            message = {"type": "display", "display": payload}
        elif etype == "delegate_start":
            message = {
                "type": "agent",
                "name": event.get("agent"),
                "display_name": event.get("display_name"),
                "state": "working",
                "run_id": event.get("run_id"),
                "task": str(event.get("task") or "")[:200],
                "model": event.get("model"),
                "model_fallback": bool(event.get("model_fallback", False)),
                "model_unusable": bool(event.get("model_unusable", False)),
                "model_unusable_detail": str(
                    event.get("model_unusable_detail") or "")[:200],
            }
        elif etype == "delegate_done":
            # W5 — a run that called only ONE of get_weather/
            # get_weather_radar leaves a lone half sitting in the merger
            # (offer() only fires once both are accounted for). Flush it
            # now rather than losing it silently: the run is over, so
            # nothing more is coming.
            flushed = weather_merger.finalize(str(event.get("run_id") or ""))
            if flushed is not None:
                try:
                    asyncio.get_running_loop().create_task(
                        send_app_message(
                            transport, {"type": "display", "display": flushed}))
                except RuntimeError:
                    pass  # no running loop (tests calling the handler directly)
            message = {
                "type": "agent",
                "name": event.get("agent"),
                "display_name": event.get("display_name"),
                "state": "done",
                "ok": bool(event.get("ok", True)),
                "detail": str(event.get("detail") or "")[:300],
            }
        elif etype == "agent_tool":
            message = {
                "type": "agent_tool",
                "name": event.get("agent"),
                "display_name": event.get("display_name"),
                "tool": event.get("tool"),
            }
        else:
            return  # agent_start / agent_done: log-only (lifecycle is delegate_*)
        try:
            asyncio.get_running_loop().create_task(
                send_app_message(transport, message))
        except RuntimeError:
            pass  # no running loop (tests calling the handler directly)

    return on_agent_event


class FramePusher:
    """Indirection so handlers built before the PipelineTask can push frames."""

    def __init__(self) -> None:
        self._task: Any = None

    def bind(self, task: Any) -> None:
        self._task = task

    async def push(self, frame: Any) -> None:
        if self._task is not None:
            await self._task.queue_frame(frame)


# Deepgram Flux keyterm boosting — proper nouns this vocabulary-heavy
# console actually needs recognized. Static by design: deriving these
# from the model registry at boot would couple STT config to
# upgrade_models.yaml for marginal benefit. Observed failure this fixes:
# "Fable 5" -> "table five" -> "Clyde's frontier model" (2026-08-17).
STT_KEYTERMS = [
    "Mortimer", "Jarvis", "Fable", "Claude", "Opus", "Kimi",
    "geolocation", "self-edit",
]


def build_pipeline(
    transport: Any, runtime: Runtime, pusher: FramePusher | None = None
) -> tuple[Pipeline, Any, Any, FramePusher]:
    """Build the locked pipeline. Returns (pipeline, llm, aggregators, pusher)."""
    settings = runtime.settings
    pusher = pusher or FramePusher()
    catalog = load_voice_catalog()
    default_voice = next(
        v for v in catalog["voices"] if v["id"] == catalog["default"])

    sub_agents = load_sub_agents(settings, runtime.registry)
    delegate_schema, delegate_handler = build_delegate_tool(
        sub_agents,
        on_event=make_agent_event_handler(transport),
        max_parallel=settings.jarvis_max_parallel_delegations,
        session_id=runtime.session_id,
        # Barge-in survival: run_session fills runtime.late_delivery["fn"]
        # with the inject_context closure once the aggregators exist, so a
        # delegation orphaned by user interruption can still deliver its
        # result into the conversation.
        late_delivery=runtime.late_delivery,
    )
    set_voice_schema, set_voice_handler = build_set_voice_tool(pusher.push, catalog)
    remember_schema, remember_handler = build_remember_tool(runtime.session_id)

    # MORTIMER_VOICE_UI_PLAN.md U1/U6 — voice control of the console's UI
    # chrome. Kill switch read here, at the single registration site (same
    # env-first pattern as the council's): false = the tool is not
    # registered and not in the schema list, so the Supervisor cannot call
    # what it cannot see, and the prompt addendum is omitted to match.
    ui_control_enabled = os.environ.get(
        "JARVIS_UI_CONTROL_ENABLED", ""
    ).strip().lower() not in ("false", "0", "no")
    # V3/V4: screen vision is a DIRECT Supervisor tool (like set_voice /
    # ui_control), never a delegation. Same kill-switch-at-registration
    # pattern as ui_control above.
    screen_enabled = os.environ.get(
        "JARVIS_SCREEN_ENABLED", ""
    ).strip().lower() not in ("false", "0", "no")
    view_screen_schema, view_screen_handler = build_view_screen_tool()
    list_screens_schema, list_screens_handler = build_list_screens_tool()

    async def _send_ui_message(message: dict) -> None:
        await send_app_message(transport, message)

    ui_control_schema, ui_control_handler = build_ui_control_tool(_send_ui_message)

    # MORTIMER_HANDOFF_LOOP_PLAN.md H3/H4/H6 — the handoff loop: show a
    # command in the display window, let Larry run it, read the output back
    # from the clipboard, continue. Same kill-switch-at-registration
    # pattern as ui_control/screen above.
    clipboard_enabled = os.environ.get(
        "JARVIS_CLIPBOARD_ENABLED", ""
    ).strip().lower() not in ("false", "0", "no")

    def _emit_display(payload: dict) -> None:
        """Direct-tool display payloads. Sub-agent tool results go through
        build_display_payload in on_agent_event; a direct Supervisor tool
        has no agent run, so it publishes its own payload in the same
        message shape the client already handles."""
        _logger.info("display_payload tool=%s surface=%s agent=%s kind=direct",
                     payload.get("tool"), payload.get("surface"), "supervisor")
        asyncio.create_task(
            send_app_message(transport, {"type": "display", "display": payload}))

    # Late-bound: the context aggregators are created further down, after
    # tools are registered. The holder is populated there; a tool can only
    # ever be CALLED once the pipeline is running, so it is always set by
    # the time this is read.
    _context_holder: dict[str, Any] = {}

    async def _inject_silent_clipboard(text: str) -> None:
        """H5 — append to the LIVE context without becoming a transcript
        entry. MemoryWatcher folds the transcript into long-term memory via
        an LLM extraction call, so clipboard content in the transcript
        could be persisted as a durable fact — a password copied moments
        earlier included. The exclusion is structural: this is not the
        speech path, and TranscriptObserver only sees the speech path."""
        user_agg = _context_holder.get("user")
        if user_agg is None:  # pragma: no cover - pipeline always sets it
            _logger.warning("clipboard_inject_dropped reason=no_context")
            return
        user_agg.add_messages([{"role": "user", "content": text}])

    def _clipboard_call(path: str, post: bool = False) -> dict:
        """One owner of the armed flag: the sidecar. The bot could run
        pbpaste itself (both processes are on Larry's Mac), but then the
        armed state would exist in two places and a clear in one would not
        arm the other."""
        from mcp_servers.mcp_selfedit.logic import AdminClient

        try:
            client = AdminClient()
            return client.post(path) if post else client.get(path)
        except Exception as exc:  # noqa: BLE001
            _logger.warning("clipboard_sidecar_unreachable path=%s error=%s", path, exc)
            return {"ok": False,
                    "error": "The admin sidecar isn't running, so I can't reach "
                             "the clipboard. Start it with ./scripts/mortimer.sh start."}

    show_commands_schema, show_commands_handler = build_show_commands_tool(
        _emit_display,
        lambda: _clipboard_call("/api/clipboard/clear", post=True),
    )
    clear_clipboard_schema, clear_clipboard_handler = build_clear_clipboard_tool(
        lambda: _clipboard_call("/api/clipboard/clear", post=True),
    )
    read_clipboard_schema, read_clipboard_handler = build_read_clipboard_tool(
        lambda: _clipboard_call("/api/clipboard"),
        _inject_silent_clipboard,
        _emit_display,
    )

    def adapt_to_pipecat(dict_handler):
        """D-009: pipecat 1.4 register_function handlers receive one
        FunctionCallParams object and deliver results via
        params.result_callback(...); jarvis function handlers keep the locked
        (arguments dict) -> confirmation str contract used by the Supervisor."""

        async def wrapper(params):
            result = await dict_handler(params.arguments)
            await params.result_callback(result)

        return wrapper
    agent_catalog = render_agent_catalog([
        {"name": a.name, "display_name": a.display_name,
         "description": a.description}
        for a in sub_agents.values()
    ])
    system_prompt = (
        SUPERVISOR_PROMPT.format(
            jarvis_name=settings.jarvis_name,
            user_name=settings.jarvis_user_name,
            timezone=settings.jarvis_timezone,
            units=settings.jarvis_units,
            agent_catalog=agent_catalog,
            voice_catalog=catalog_summary(catalog),
            memory_context=render_memory_context(),  # U2.5 persistent memory
        )
        + "\n"
        + VOICE_ADDENDUM
        # U5/U6: the addendum ships only when the tool does — a prompt
        # describing an unregistered tool would invite hallucinated calls.
        + ("\n" + UI_CONTROL_ADDENDUM if ui_control_enabled else "")
        + ("\n" + SCREEN_VISION_ADDENDUM if screen_enabled else "")
        # H3/H6 — show_commands is always registered; the clipboard half
        # of the addendum only makes sense when its tools are.
        + ("\n" + HANDOFF_ADDENDUM if clipboard_enabled else "")
    )

    stt = DeepgramFluxSTTService(
        api_key=settings.deepgram_api_key,
        settings=DeepgramFluxSTTSettings(
            model="flux-general-en", keyterm=STT_KEYTERMS,
        ),
        # was True (plan Phase 5, D-004) until 2026-08-22. With
        # should_interrupt=True, Flux broadcasts an interruption on EVERY
        # StartOfTurn — at VAD level, before any transcript or speaker
        # score exists — so the speaker gate's verification never saw it:
        # the TV kept killing in-flight replies "before any audio played"
        # (26 broadcasts in one 19-minute session, 2026-08-21 logs) even
        # while every TV transcript was being correctly dropped. False
        # hands interruption duty to the ONE gated path that already
        # exists: the user-turn-start strategy below (speaker-verified
        # min-words while the bot is speaking), whose trigger makes the
        # LLMUserAggregator broadcast the interruption. Cost: barge-in now
        # fires at first transcript (~0.5s after speech starts) instead of
        # at VAD onset — an unverified interruption a TV can fire is worse
        # than a verified one that arrives half a second later.
        should_interrupt=False,
    )
    # MORTIMER_VOICE_MODEL_BENCH_PLAN.md V3 — provider-aware Supervisor
    # service. Google's OpenAI-compat endpoint CANNOT carry the voice loop:
    # Gemini 3 requires thought signatures echoed back on history replay,
    # and pipecat's OpenAI streaming aggregation (base_llm._process_context)
    # coalesces tool calls down to id/name/arguments, destroying the
    # signature before anything downstream could preserve it. Pipecat's
    # NATIVE GoogleLLMService handles signatures completely (capture,
    # bookmark, re-apply on replay — services/google/llm.py), so a Google
    # base_url routes there. Everything else keeps OpenAILLMService
    # unchanged. Lazy import: google-genai is an optional dependency and a
    # non-Google deployment must not need it installed.
    if "generativelanguage.googleapis.com" in (settings.openai_base_url or ""):
        from pipecat.services.google.llm import GoogleLLMService
        llm = GoogleLLMService(
            api_key=settings.openai_api_key,
            model=settings.openai_model,
        )
        _logger.info("supervisor_llm_service service=google model=%s",
                     settings.openai_model)
    else:
        llm = OpenAILLMService(
            api_key=settings.openai_api_key,
            base_url=settings.openai_base_url,
            model=settings.openai_model,
        )
    llm.register_function("delegate_task", adapt_to_pipecat(delegate_handler))
    llm.register_function("set_voice", adapt_to_pipecat(set_voice_handler))
    llm.register_function("remember", adapt_to_pipecat(remember_handler))
    if ui_control_enabled:
        llm.register_function("ui_control", adapt_to_pipecat(ui_control_handler))
    if screen_enabled:
        llm.register_function("view_screen", adapt_to_pipecat(view_screen_handler))
        llm.register_function("list_screens", adapt_to_pipecat(list_screens_handler))
    # H3 — show_commands is registered regardless of the clipboard switch:
    # putting a command on screen instead of speaking it is useful even
    # when the return channel is off. Only the clipboard pair is gated.
    llm.register_function("show_commands", adapt_to_pipecat(show_commands_handler))
    if clipboard_enabled:
        llm.register_function(
            "clear_clipboard", adapt_to_pipecat(clear_clipboard_handler))
        llm.register_function(
            "read_clipboard", adapt_to_pipecat(read_clipboard_handler))
    tts = ElevenLabsTTSService(
        api_key=settings.elevenlabs_api_key,
        settings=ElevenLabsTTSSettings(
            voice=default_voice["elevenlabs_voice_id"],
            model="eleven_flash_v2_5",
            stability=0.5,
            similarity_boost=0.75,
        ),
    )

    def to_function_schema(schema: dict) -> FunctionSchema:
        fn = schema["function"]
        return FunctionSchema(
            name=fn["name"],
            description=fn["description"],
            properties=fn["parameters"]["properties"],
            required=fn["parameters"]["required"],
        )

    standard_tools = [
        to_function_schema(delegate_schema),
        to_function_schema(set_voice_schema),
        to_function_schema(remember_schema),
    ]
    if ui_control_enabled:
        standard_tools.append(to_function_schema(ui_control_schema))
    if screen_enabled:
        standard_tools.append(to_function_schema(view_screen_schema))
        standard_tools.append(to_function_schema(list_screens_schema))
    standard_tools.append(to_function_schema(show_commands_schema))
    if clipboard_enabled:
        standard_tools.append(to_function_schema(clear_clipboard_schema))
        standard_tools.append(to_function_schema(read_clipboard_schema))
    context = LLMContext(
        messages=[{"role": "system", "content": system_prompt}],
        tools=ToolsSchema(standard_tools=standard_tools),
    )
    # Tier 2 (MORTIMER_VOICE_ISOLATION_TIER12_PLAN.md §4.3) — a local
    # speaker-verification gate on final transcripts. Inserted ONLY when
    # all three hold: the kill switch is on, a profile is enrolled, and the
    # embedding model actually loads from disk. Any one missing means
    # NEITHER processor is added — a half-configured gate costs nothing and
    # changes nothing, matching the fail-open discipline in jarvis/speaker.py.
    # Constructed BEFORE the aggregators because the Tier 1b turn-start
    # strategy below shares the gate's state when the gate is active.
    # F3 (MORTIMER_GATE_V2_AND_MODEL_REQUEST_PLAN.md, 2026-08-22) split
    # this block: TranscriptGate's honest-drop note needs a way to append
    # to the shared context (the same silent-append mechanism as
    # inject_silent below), which only exists once `aggregators` is
    # built. So gate/profile/encoder setup happens here, but
    # TranscriptGate itself is constructed further down, right after
    # `aggregators` — construction ORDER doesn't have to match the
    # pipeline's processor LIST order (assembled separately below).
    speaker_tap = None
    speaker_transcript_gate = None
    speaker_gate_state = None
    if speaker.enabled():
        profile = speaker.load_profile()
        encoder = speaker.Encoder()
        if profile is None:
            _logger.info("speaker_gate_inactive reason=no_profile")
        elif not encoder.load():
            _logger.info("speaker_gate_inactive reason=encoder_load_failed")
        else:
            speaker_gate_state = GateState()
            speaker_tap = SpeakerTap(speaker_gate_state, encoder, profile)
    else:
        _logger.info("speaker_gate_inactive reason=kill_switch_off")

    # Tier 1b (MORTIMER_VOICE_ISOLATION_TIER12_PLAN.md §3, REWIRED for
    # pipecat 1.4 on 2026-08-21): in 1.4 turn strategies live on the USER
    # AGGREGATOR, not PipelineTask — the plan's original
    # PipelineParams(interruption_strategies=...) path was verified against
    # a 0.0.108 install and does not exist here (the first boot died on the
    # import). min_words applies ONLY while the bot is speaking (a cough or
    # "hm" no longer interrupts TTS); when the bot is quiet, a single word
    # still starts a turn normally. When the speaker gate is active, the
    # strategy ALSO requires a passing speaker score to allow an
    # interruption (first live session: the TV never got a transcript
    # through, but it interrupted Mortimer constantly — transcripts alone
    # were the wrong boundary). Barge-in survival (2026-08-21) already
    # makes real interruptions non-destructive; this cuts spurious ones.
    if speaker_gate_state is not None:
        turn_start_strategy = SpeakerVerifiedMinWordsTurnStartStrategy(
            speaker_gate_state, min_words=2
        )
    else:
        turn_start_strategy = MinWordsUserTurnStartStrategy(min_words=2)
    aggregators = LLMContextAggregatorPair(
        context,
        user_params=LLMUserAggregatorParams(
            user_turn_strategies=UserTurnStrategies(
                start=[turn_start_strategy],
            ),
        ),
    )
    # H4/H5 — hand the user aggregator to the clipboard injector built
    # above. Set here because the tools are registered before this line.
    _context_holder["user"] = aggregators.user()

    # F3 — now that `aggregators` exists, finish constructing the gate:
    # its honest-drop note appends to the SAME shared context
    # inject_silent (below, in run_session) uses — a plain
    # add_messages() call, never push_context_frame(), so a drop note
    # surfaces on the next real turn instead of an unprompted spoken
    # reply. Only built when the gate is actually active (speaker_gate_
    # state is not None); a disabled/half-configured gate still costs
    # nothing.
    if speaker_gate_state is not None:
        async def _inject_speaker_drop_note(text: str) -> None:
            aggregators.user().add_messages([{"role": "user", "content": text}])

        speaker_transcript_gate = TranscriptGate(
            speaker_gate_state,
            lambda message: send_app_message(transport, message),
            profile_loaded=True,
            inject=_inject_speaker_drop_note,
        )
        _logger.info("speaker_gate_active threshold=%.2f", speaker.threshold())
    # TranscriptObserver (run_session) filters persisted USER lines through
    # this: a gated pipeline must never write a dropped speaker's words to
    # the conversations table (the memory sweep folds that table into
    # long-term memory — observed live 2026-08-21: TV dialogue persisted).
    runtime.speaker_gate = speaker_transcript_gate

    transcript = TranscriptLogger(session_id=runtime.session_id)

    pipeline_steps = [
        transport.input(),
        # stop_secs 2.5 (default 0.2): wiring tuning so a mid-sentence pause
        # (~2 s) does not trigger the local smart-turn analyzer to close the
        # turn early (Phase 4 acceptance item 11; recorded in DEVIATIONS.md
        # D-010). Turn end is decided by pipecat's TurnAnalyzer on VAD stop,
        # so the VAD stop window is the lever — Flux EOT only finalizes
        # transcripts, which accumulate harmlessly mid-turn.
        VADProcessor(vad_analyzer=SileroVADAnalyzer(params=VADParams(stop_secs=2.5))),
    ]
    if speaker_tap is not None:
        pipeline_steps.append(speaker_tap)
    pipeline_steps.append(stt)
    if speaker_transcript_gate is not None:
        pipeline_steps.append(speaker_transcript_gate)
    pipeline_steps.extend([
        aggregators.user(),
        llm,
        transcript,
        tts,
        transport.output(),
        aggregators.assistant(),
    ])
    pipeline = Pipeline(pipeline_steps)
    return pipeline, llm, aggregators, pusher


def _wrap_rtvi(message: dict) -> dict:
    """D-005: client-js 1.13 drops data-channel messages that are not
    rtvi-ai labeled, so app payloads are wrapped in a server-message
    envelope. The payload itself keeps the locked shape."""
    return {
        "id": str(uuid.uuid4()),
        "label": "rtvi-ai",
        "type": "server-message",
        "data": message,
    }


def _unwrap_client_message(message: Any) -> dict | None:
    """D-005: normalize inbound client messages to the locked raw shape.

    Accepts the locked shape ({"type": "voice/set", ...}) verbatim, plus the
    client-js RTVI envelope ({"type": "client-message",
    "data": {"t": <type>, "d": {...}}}) — client-js 1.13 has no raw
    sendAppMessage, its sendClientMessage always wraps.
    """
    if not isinstance(message, dict):
        return None
    if message.get("type") == "client-message":
        data = message.get("data")
        if not isinstance(data, dict):
            return None
        msg_type = data.get("t")
        payload = data.get("d")
        if not isinstance(msg_type, str):
            return None
        return {"type": msg_type, **(payload if isinstance(payload, dict) else {})}
    return message


async def send_app_message(transport: Any, message: dict) -> None:
    """Server->client app message over the WebRTC data channel."""
    await transport.output().send_message(
        OutputTransportMessageUrgentFrame(message=_wrap_rtvi(message)))


async def run_session(transport: Any, webrtc_connection: Any = None) -> None:
    """Build per-connection resources and run the pipeline to completion."""
    settings = load_settings()
    bridge_settings_to_env(settings)
    run_migrations()
    # Enable INFO root logging so registry/subagent lifecycle lines
    # (mcp_server_started, subagent_done, turn_complete) reach logs/bot.log.
    setup_logging()

    # Run-logging plan D10/§5.8: retention pruning runs once at startup —
    # outside the latency-critical per-turn path, guaranteed to happen
    # regularly, no scheduler needed. Best-effort; a failure here must
    # never block the bot from starting.
    try:
        prune_counts = prune_runlog(settings.jarvis_runlog_retention_days)
        _logger.info(
            "runlog_prune runs_deleted=%d dirs_deleted=%d",
            prune_counts["runs_deleted"], prune_counts["dirs_deleted"],
        )
    except Exception as exc:  # noqa: BLE001 — must never block startup
        _logger.warning("runlog_prune_failed error=%s", exc)

    # MORTIMER_LLM_COUNCIL_V2_PLAN.md V11: council retention pruning, same
    # startup moment and best-effort shape as the runlog prune above.
    try:
        council_prune_counts = prune_council(settings.jarvis_council_retention_days)
        _logger.info(
            "council_prune rounds_deleted=%d dirs_deleted=%d",
            council_prune_counts["rounds_deleted"], council_prune_counts["dirs_deleted"],
        )
    except Exception as exc:  # noqa: BLE001 — must never block startup
        _logger.warning("council_prune_failed error=%s", exc)

    # MORTIMER_AGENT_TRUST_PLAN.md D16: reconcile orphaned runs at the same
    # startup moment as the retention prune above — nothing is `running`
    # in this process yet, so any row still marked `running` from a
    # previous, now-dead process is definitionally orphaned. Best-effort,
    # same as the prune call: must never block the bot from starting.
    try:
        orphaned_count = reconcile_orphaned_runs()
        if orphaned_count:
            _logger.info("runlog_reconcile_orphaned count=%d", orphaned_count)
    except Exception as exc:  # noqa: BLE001 — must never block startup
        _logger.warning("runlog_reconcile_orphaned_failed error=%s", exc)

    # MORTIMER_KEY_VALIDITY_PLAN.md K4: probe every configured model
    # credential once, on a daemon thread, at the same startup moment as the
    # prunes above. Detached rather than awaited for the same reason the
    # council's shadow pass is (V7): a measurement must never delay the
    # thing being measured. Boot proceeds immediately; verdicts land a few
    # seconds later and are read at delegation time, so the first run of a
    # session may legitimately see `unknown` — which is not `unusable`.
    try:
        from jarvis import keyhealth

        if keyhealth.start_background_probe() is not None:
            _logger.info("key_health_probe_started")
    except Exception as exc:  # noqa: BLE001 — must never block startup
        _logger.warning("key_health_probe_start_failed error=%s", exc)

    # MORTIMER_SKILL_LIBRARY_PLAN.md Part G: prune retained screen-vision
    # diagnostic images, same startup moment and same best-effort shape as
    # the two prunes above. This is what makes the retention window real
    # rather than promised — a low-confidence capture kept for
    # troubleshooting cannot outlive JARVIS_SCREEN_RETENTION_HOURS even if
    # nothing else ever runs.
    try:
        from mcp_servers.mcp_screen.logic import prune_screen_logs

        pruned_screens = prune_screen_logs()
        if pruned_screens:
            _logger.info("screen_logs_pruned count=%d", pruned_screens)
    except Exception as exc:  # noqa: BLE001 — must never block startup
        _logger.warning("screen_prune_failed error=%s", exc)

    # MORTIMER_MEMORY_AUTOCONSOLIDATION_PLAN.md A1/A2/A4/A5: same startup
    # moment and same detached-thread shape as the key-health probe above
    # — a memory cleanup pass must never delay boot, and its one small
    # model call (batched contradiction + audience classification) has no
    # business happening on the latency-critical path.
    try:
        from jarvis import memory_sweep

        if memory_sweep.start_background_sweep() is not None:
            _logger.info("memory_sweep_started")
    except Exception as exc:  # noqa: BLE001 — must never block startup
        _logger.warning("memory_sweep_start_failed error=%s", exc)

    registry = SkillRegistry(REPO_ROOT / "config" / "mcp_servers.yaml")
    await registry.start()
    runtime = Runtime(settings=settings, registry=registry,
                      session_id=str(uuid.uuid4()))
    print(f"[session] {runtime.session_id}", flush=True)

    try:
        catalog = load_voice_catalog()
        pipeline, _llm, aggregators, pusher = build_pipeline(transport, runtime)
        async def inject_silent(text: str) -> None:
            # Phase 3: interruption notice. Unlike inject_context (greeting,
            # reminders), this does NOT call push_context_frame() — it only
            # appends to the shared context so the note surfaces naturally on
            # the next real user turn instead of triggering an immediate,
            # unprompted spoken reply.
            aggregators.user().add_messages([{"role": "user", "content": text}])

        # D-007: user-side transcript logging lives in a task observer because
        # pipecat 1.4's user aggregator consumes TranscriptionFrame; the locked
        # 9-processor order is unchanged. InterruptionNotifier is a task
        # observer for the same reason: BotStartedSpeakingFrame/
        # BotStoppedSpeakingFrame are born downstream of the TTS service.
        # G12 — a small task observer feeding ProgressWatcher's "don't speak
        # over anyone" suppression; same D-007/Phase-3 pattern
        # InterruptionNotifier already uses (BotStartedSpeakingFrame/
        # BotStoppedSpeakingFrame are born downstream of the TTS service).
        speaking_tracker = SpeakingStateTracker()
        observers = [
            TranscriptObserver(runtime.session_id, only_from=runtime.speaker_gate),
            InterruptionNotifier(
                inject_silent,
                enabled=settings.jarvis_interruption_notice_enabled,
            ),
            speaking_tracker,
        ]
        if os.environ.get("JARVIS_DEBUG_OBSERVER"):
            # Temporary diagnostic: print every function-call frame hop with
            # timestamps to find where post-result frames stall.
            from pipecat.frames.frames import (
                FunctionCallInProgressFrame,
                FunctionCallResultFrame,
            )
            from pipecat.observers.base_observer import BaseObserver

            class _FnFrameProbe(BaseObserver):
                async def on_push_frame(self, data) -> None:
                    if isinstance(
                        data.frame,
                        (FunctionCallInProgressFrame, FunctionCallResultFrame),
                    ):
                        src = type(data.source).__name__ if data.source else "?"
                        dst = (
                            type(data.destination).__name__
                            if data.destination else "?"
                        )
                        print(
                            f"[FNPROBE] {type(data.frame).__name__} "
                            f"{src}->{dst} dir={data.direction}",
                            flush=True,
                        )

            observers.append(_FnFrameProbe())
        task = PipelineTask(pipeline, observers=observers)
        pusher.bind(task)

        client_connected = {"value": False}

        @transport.event_handler("on_client_connected")
        async def on_client_connected(transport: Any, client: Any) -> None:
            print("[session] client connected", flush=True)
            client_connected["value"] = True
            await send_app_message(transport, {
                "type": "voice/catalog",
                "voices": catalog["voices"],
                "current": catalog["default"],
            })
            # D-008: pipecat 1.4 has add_messages (plural) and requires an
            # explicit push_context_frame() to trigger the LLM run.
            # Include the user's local time: the model has no clock, and a
            # blind greeting guesses the wrong time of day.
            now_local = datetime.now(ZoneInfo(settings.jarvis_timezone))
            greeting_time = now_local.strftime("%I:%M %p").lstrip("0")
            greeting_note = (
                "[system] The user just connected. Greet them briefly by "
                f"name; it is {greeting_time} their time."
            )
            # MORTIMER_MEMORY_AUTOCONSOLIDATION_PLAN.md A3: offered once
            # per connect, never repeating in-session (same ambient-strip
            # dismiss discipline as the reminder/weather chips) — a
            # dismissed offer is not the same as a resolved review, so
            # this simply doesn't re-fire until the NEXT connect.
            try:
                from jarvis import memory_sweep

                review_count = memory_sweep.open_review_count()
                if review_count > 0:
                    # 2026-08-21, from a live miss: the announcement alone
                    # sent the model hunting for a tool that doesn't exist
                    # (it tried librarian, then developer, which punted to
                    # a curl handoff) when the list was already rendered in
                    # the console. Showing the queue is a VIEW change, so
                    # the note names the exact ui_control call — same
                    # disambiguation rule 8 makes for panels generally.
                    greeting_note += (
                        f" You also have {review_count} memory "
                        "conflict(s)/cleanup item(s) waiting for review — "
                        "mention this in one short sentence after greeting "
                        "them. Two ways to handle them: to SHOW the list, "
                        "call ui_control with action=drawer_tab, tab=memory "
                        "(never a delegation); to work through them BY "
                        "VOICE, delegate to librarian, which can list each "
                        "item and resolve it per the user's choice."
                    )
            except Exception as exc:  # noqa: BLE001 — greeting must never fail
                _logger.warning("memory_review_greeting_check_failed error=%s", exc)
            aggregators.user().add_messages([{
                "role": "user", "content": greeting_note,
            }])
            await aggregators.user().push_context_frame()

        @transport.event_handler("on_client_disconnected")
        async def on_client_disconnected(transport: Any, client: Any) -> None:
            print("[session] client disconnected", flush=True)
            client_connected["value"] = False
            # End the pipeline task so `await runner.run(task)` returns and the
            # finally block below actually runs. Without this the task blocks
            # forever after the client goes away: the session's memory fold-in
            # never happens (facts/observations are lost until process exit,
            # and only for the last session) and RemindersWatcher leaks one
            # polling task per connection. One PipelineTask is built per
            # WebRTC connection (jarvis/bot/bot.py builds a fresh transport
            # and calls run_session per connection), so cancelling here ends
            # only this session — a reconnect gets a new pipeline.
            await task.cancel()

        async def inject_context(text: str) -> None:
            # D-008: same 1.4 context-injection pattern as the greeting.
            aggregators.user().add_messages([{"role": "user", "content": text}])
            await aggregators.user().push_context_frame()

        # Barge-in survival — install the late-delivery hook the delegate
        # tool uses for results whose voice turn was cancelled. Same
        # inject_context channel the reminders watcher speaks through: the
        # result arrives as a context note and Mortimer reports it on its
        # own initiative, exactly like a due reminder.
        runtime.late_delivery["fn"] = inject_context

        watcher = RemindersWatcher(
            runtime.registry,
            inject=inject_context,
            is_connected=lambda: client_connected["value"],
        )
        watcher.start()

        # Reliable-memory plan D2: periodic mid-session fold-in, so an
        # unclean disconnect loses at most one sweep interval instead of
        # everything discussed. The end-of-session call below remains — it
        # is the last sweep, covering anything since the watcher's last tick.
        memory_watcher = MemorySweepWatcher(
            settings, runtime.session_id, settings.jarvis_memory_sweep_interval_s,
        )
        memory_watcher.start()

        # F4 (MORTIMER_CONFIRMATION_AND_CAPABILITY_PLAN.md): a background
        # plan/review job finishes in the SIDECAR, which has no voice. The
        # watcher polls it and announces completion once, pushing the
        # finished document through the existing display pipeline
        # (display.py's plan_ready pseudo-tool). Kill switch:
        # JARVIS_PLAN_WATCHER_ENABLED=false.
        plan_watcher = None
        if os.environ.get("JARVIS_PLAN_WATCHER_ENABLED", "").strip().lower() not in (
            "false", "0", "no",
        ):
            async def _speak_plan(text: str) -> None:
                from pipecat.frames.frames import TTSSpeakFrame
                await pusher.push(TTSSpeakFrame(text=text))

            async def _push_plan_display(payload: dict) -> None:
                await send_app_message(transport, {"type": "display", "display": payload})

            plan_watcher = PlanWatcher(
                speak=_speak_plan,
                push_display=_push_plan_display,
                is_connected=lambda: client_connected["value"],
            )
            plan_watcher.start()

        # MORTIMER_SITE_RESEARCH_AND_COMPARISON_PLAN.md R7 — same rationale
        # as plan_watcher above: a background site comparison finishes in
        # the sidecar, which has no voice. Kill switch:
        # JARVIS_RESEARCH_WATCHER_ENABLED=false (independent of R10's
        # JARVIS_RESEARCH_ENABLED, which disables the feature itself).
        research_watcher = None
        if os.environ.get("JARVIS_RESEARCH_WATCHER_ENABLED", "").strip().lower() not in (
            "false", "0", "no",
        ):
            async def _speak_research(text: str) -> None:
                from pipecat.frames.frames import TTSSpeakFrame
                await pusher.push(TTSSpeakFrame(text=text))

            async def _push_research_display(payload: dict) -> None:
                await send_app_message(transport, {"type": "display", "display": payload})

            research_watcher = ResearchWatcher(
                speak=_speak_research,
                push_display=_push_research_display,
                is_connected=lambda: client_connected["value"],
            )
            research_watcher.start()

        # G12 (MORTIMER_SESSION_GAPS_AND_SELFEDIT_CONVERGENCE_PLAN.md) —
        # verbal "still working" pings every 30s while a delegation or
        # self-edit run is in flight. Kill switch:
        # JARVIS_PROGRESS_UPDATES_ENABLED=false.
        progress_watcher = None
        if os.environ.get("JARVIS_PROGRESS_UPDATES_ENABLED", "").strip().lower() not in (
            "false", "0", "no",
        ):
            async def _speak_progress(text: str) -> None:
                from pipecat.frames.frames import TTSSpeakFrame
                await pusher.push(TTSSpeakFrame(text=text))

            progress_watcher = ProgressWatcher(
                speak=_speak_progress,
                is_connected=lambda: client_connected["value"],
                is_speaking=speaking_tracker.is_busy,
                session_id=runtime.session_id,
            )
            progress_watcher.start()

        voice_state = {"current": catalog["default"]}

        async def handle_voice_set(message: Any) -> None:
            msg = _unwrap_client_message(message)
            if msg is None or msg.get("type") != "voice/set":
                return
            print(f"[appmsg] voice/set: {msg.get('voice')}", flush=True)
            voice = resolve_voice(str(msg.get("voice", "")), catalog)
            if voice is not None:
                from pipecat.frames.frames import TTSUpdateSettingsFrame
                voice_state["current"] = voice["id"]
                await pusher.push(TTSUpdateSettingsFrame(
                    settings={"voice": voice["elevenlabs_voice_id"]}))
            # Reply on failure too (unchanged id) so the UI reconciles its
            # optimistic select against server truth.
            await send_app_message(transport, {
                "type": "voice/current", "voice": voice_state["current"]})

        async def handle_ui_noop(message: Any) -> None:
            """MORTIMER_VOICE_UI_PLAN.md U2 — the hybrid feedback's spoken
            half. When a ui_control command changed nothing client-side
            (drawer already open, wake sidecar unavailable), the client
            sends {"type": "ui/noop", "reason": "<sentence>"} and the bot
            speaks the reason VERBATIM via TTSSpeakFrame — deliberately
            NOT through the LLM: the tool call already returned "ok" and
            the Supervisor's turn is over by the time the no-op is
            detected, so canned TTS is immediate, deterministic, and
            costs no tokens. No LLM involvement also means this path can
            never trigger further tool calls (no feedback loop)."""
            msg = _unwrap_client_message(message)
            if msg is None or msg.get("type") != "ui/noop":
                return
            reason = str(msg.get("reason", "")).strip()
            if not reason or len(reason) > 200:
                return
            print(f"[appmsg] ui/noop: {reason}", flush=True)
            from pipecat.frames.frames import TTSSpeakFrame
            await pusher.push(TTSSpeakFrame(text=reason))

        if webrtc_connection is not None:
            # D-005 update: on the installed pipecat 1.4.0 runner stack the
            # transport-level on_app_message event demonstrably does NOT
            # dispatch to handlers registered as above (the message reaches
            # the pipeline as InputTransportMessageFrame — the runner-added
            # RTVIProcessor logs "Ignoring not RTVI message" — but the
            # transport event never fires our handler). The connection-level
            # "app-message" event is the same event the transport itself
            # subscribes to; registering there is the working receive path
            # for both the locked raw shape and the client-js envelope.
            #
            # MORTIMER_AGENT_TRUST_PLAN.md D19: the dead transport-level
            # on_app_message handler (registered via @transport's own
            # event_handler decorator) that used to sit above this comment
            # never fired, per the D-005 note above, and has been removed.
            # Its removal was gated on the plan's exact precondition —
            # grepping this file for the connection-level registration
            # immediately below and confirming it was the ONLY match —
            # before deleting anything.
            @webrtc_connection.event_handler("app-message")
            async def on_connection_app_message(connection: Any, message: Any) -> None:
                await handle_voice_set(message)
                await handle_ui_noop(message)

        runner = PipelineRunner()
        try:
            await runner.run(task)
        finally:
            await watcher.stop()
            await memory_watcher.stop()
            if plan_watcher is not None:
                await plan_watcher.stop()
            if research_watcher is not None:
                await research_watcher.stop()
            if progress_watcher is not None:
                await progress_watcher.stop()
            # U2.5: fold this session into long-term memory. Best-effort,
            # hard-capped — memory work must never delay shutdown.
            #
            # Reliable-memory plan D1: the only failure this outer except can
            # actually catch is asyncio.TimeoutError from the wait_for below
            # (update_memory_from_session already catches and logs every
            # internal failure itself). Previously that specific case was
            # swallowed with zero log line, making it impossible to tell from
            # the logs whether a session's memory fold-in happened, timed
            # out, or errored.
            try:
                await asyncio.wait_for(
                    update_memory_from_session(settings, runtime.session_id),
                    timeout=MEMORY_EXTRACTION_TIMEOUT_S,
                )
            except asyncio.TimeoutError:
                _logger.warning(
                    "memory_extraction_timeout session=%s", runtime.session_id
                )
            except Exception:  # noqa: BLE001 — memory must never break shutdown
                _logger.exception(
                    "memory_extraction_failed session=%s", runtime.session_id
                )
    finally:
        await registry.stop()
