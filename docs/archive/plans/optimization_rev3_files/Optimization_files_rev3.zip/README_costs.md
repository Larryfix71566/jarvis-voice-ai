# Cost Tracking — Integration Steps (Rev 3, 2026-09-01 — conflicts resolved)

Confirmed architecture this design is built against:
- **Every** completion in this repo goes through `AsyncOpenAI` /
  `chat.completions.create` — no native Anthropic Messages API client
  anywhere. Anthropic, Moonshot, and OpenRouter are all reached by
  pointing the same client class at a different `base_url`. One adapter
  (`record_completion`) handles all eleven call sites; there is no
  per-vendor SDK split.
- `.env`'s `OPENAI_BASE_URL`/`OPENAI_MODEL`/`OPENAI_API_KEY` currently
  point at **Anthropic** (`https://api.anthropic.com/v1/`,
  `claude-haiku-4-5`) — the names are a historical artifact, not a
  vendor signal. `provider_from_base_url()` derives the real provider
  from the live client's `base_url` at call time, so this stays correct
  even if `.env` is repointed later.
- **Two writer PROCESSES from day one.** `council.py` and
  `upgrade_agent.py` run inside the admin sidecar (`jarvis/admin/
  server.py`, `:7861`); every other call site runs inside the bot
  (`:7860`). The ledger therefore opens in WAL mode with a busy timeout
  on every connection and anchors `data/costs.db` to the repo root — not
  the CWD, because the two processes are launched by different scripts.
- **9 of 11 rungs** (scheduler, librarian, analyst, systems, supervisor,
  memory_merge, memory_classify, memory_extraction, kb_digest,
  procedures_describe) share that one default model today. Only
  `developer` (`model_profile: claude-opus`) and `council` (per-member,
  drawing from `config/upgrade_models.yaml`) route differently.

Files and where they land:

| File | Destination |
|---|---|
| usage_ledger.py | `jarvis/usage_ledger.py` |
| model_prices.yaml | `config/model_prices.yaml` |
| pull_openrouter_activity.py | `scripts/pull_openrouter_activity.py` |
| cost_report.py | `scripts/cost_report.py` |
| costs_api.py | `jarvis/costs_api.py` |
| CostDashboardView.swift | interface project |
| patches_confirmed_sites.py | reference only — apply the 11 inline patches below by hand or via Claude Code; not a file that lives in the repo |

## Wiring order

1. **Drop in `usage_ledger.py` and `model_prices.yaml` as-is.** The price
   map's rates are placeholders (`0.0`) — fill from each vendor's current
   pricing page. Token counts are accurate the moment the shim is wired;
   dollar figures are not until this file is filled in. Keys are
   `"{provider}/{model}"`, built by the ledger itself — don't key by bare
   model string alone (`base.py` and `council.py` store the model string
   differently — see the comment at the top of the price map).

2. **Wire all THIRTEEN call sites** per `patches_confirmed_sites.py`
   (Rev 3 added `upgrade_agent.py:469` — the executor loop, previously
   deferred on a mistaken double-count worry — and a `rung` kwarg on
   `council._call_profile` so planning/research calls are not labelled
   "council"). Rung names come from the closed set `usage_ledger.RUNGS`;
   an unknown rung still records but prints one stderr line. Every site
   follows one of three shapes:
   - **Nine settings-default sites** (supervisor, both memory_sweep
     sites, memory.py, kb_digest.py, procedures.py, and — via one shared
     hook — scheduler/librarian/analyst/systems/developer in `base.py`):
     `provider=provider_from_base_url(str(client.base_url))`, `model=`
     whatever local variable was already passed to
     `chat.completions.create`.
   - **`council.py`**, one site, dynamic per member: `provider=
     profile.get("provider")`, `model=profile.get("identity", ...)` —
     read straight from the resolved `upgrade_models.yaml` profile
     dict, not derived; `rung` from the new kwarg (`council` default,
     `planning` / `research` from the three non-council callers).
   - **`upgrade_agent.py:469`**, the sidecar's own edit-loop completion:
     `rung=f"{self._council_workflow}_executor"` (→ `selfedit_executor`
     or `appbuild_executor`, AppBuildAgent inherits it), `model=
     request["model"]` because the failover path can swap the client.
   Every call is wrapped in `try/except: pass` — cost logging must never
   break a live voice turn or a tool-calling loop.

3. **Costs service.** Add to the existing `Procfile` (see
   `procfile_addition.txt`):
   ```
   costs: uvicorn jarvis.costs_api:app --port 8487
   ```
   Optional budget: set `JARVIS_MONTHLY_BUDGET_USD` in `.env`.

4. **Voice skill (A).** Wire your skill format to call
   `jarvis.costs_api.summary_text()` directly, or GET `/costs/summary`
   and speak the `spoken` field.

5. **SwiftUI card (B).** Drop `CostDashboardView` into the interface,
   point `baseURL` at the costs service. Swift Charts, no packages.

6. **OpenRouter enrichment.** Run manually during Phase 0, cron/daily
   after:
   ```
   python scripts/pull_openrouter_activity.py
   ```
   Backfills reported cost + cached tokens per generation, prints
   remaining credit balance. `--raw` dumps the first raw responses if
   the generation endpoint's fields have drifted. Requires
   `OPENROUTER_API_KEY` in the vault.

7. **Verify the cache-field assumption before trusting any cache column.**
   This is the one thing in this whole set that's genuinely unverified:
   whether Anthropic's and Moonshot's OpenAI-compatible endpoints
   populate `prompt_tokens_details.cached_tokens` (or any equivalent)
   when hit via `chat.completions.create`, the way OpenAI's own API does.
   Set `JARVIS_DEBUG_USAGE_LEDGER=1`, run one two-turn session so a cache
   hit should be possible, and read the raw `usage` object printed to
   stderr for each provider. If it's empty on the direct-Anthropic path,
   the `developer`/`claude-opus` rung — your priciest — is flying blind
   on caching, which changes Phase 1's priority for that rung
   specifically.

8. **Baseline report** after ~a week of normal use:
   ```
   python scripts/cost_report.py
   ```
   Totals, per-rung share, cache hit rates, A1/A3/A5 verdicts — feeds
   the plan's savings ledger with real numbers.

## Notes

- Ledger: SQLite at `<repo>/data/costs.db`, calendar-month periods,
  **WAL from the first row** (bot + sidecar are two writer processes
  today; the Phase 2 extraction worker will be a third and needs nothing
  further). The in-process `threading.Lock` only orders threads within
  one process — cross-process ordering is SQLite's.
- `record_completion` is the ONLY adapter — there is no `record_anthropic`
  / `record_openai` split in the final design; that split was based on an
  assumption (separate SDK clients per vendor) this repo doesn't match.
- Price map keys are provider-qualified specifically because `base.py`
  and `council.py` store the model identifier differently (bare wire
  string vs. vendor-prefixed `identity`) — see `model_prices.yaml`'s
  header comment before adding new rows.
