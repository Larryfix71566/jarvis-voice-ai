// CostDashboardView.swift — monthly cost card for the Mortimer interface.
// Consumes GET /costs/summary and /costs/daily (costs_api.py, default :8487).
// Swift Charts for the daily sparkline; no third-party dependencies.
// Adjust `baseURL` to wherever the costs service lands in your setup.

import SwiftUI
import Charts

// MARK: - Models (mirror costs_api.py payloads)

struct CostSummary: Codable {
    let month: String
    let calls: Int
    let totalUsd: Double
    let projectedUsd: Double
    let byRung: [RungCost]
    let byProvider: [ProviderCost]
    let budgetUsd: Double
    let budgetUsedPct: Double
    let unpricedCalls: Int

    enum CodingKeys: String, CodingKey {
        case month, calls
        case totalUsd = "total_usd"
        case projectedUsd = "projected_usd"
        case byRung = "by_rung"
        case byProvider = "by_provider"
        case budgetUsd = "budget_usd"
        case budgetUsedPct = "budget_used_pct"
        case unpricedCalls = "unpriced_calls"
    }
}

struct RungCost: Codable, Identifiable {
    let rung: String
    let usd: Double
    var id: String { rung }
}

struct ProviderCost: Codable, Identifiable {
    let provider: String
    let usd: Double
    var id: String { provider }
}

struct DailyCost: Codable, Identifiable {
    let day: String
    let usd: Double
    var id: String { day }
}

private struct DailyResponse: Codable {
    let month: String
    let daily: [DailyCost]
}

// MARK: - Fetch

@MainActor
final class CostModel: ObservableObject {
    @Published var summary: CostSummary?
    @Published var daily: [DailyCost] = []
    @Published var error: String?

    let baseURL = URL(string: "http://127.0.0.1:8487/costs")!

    func refresh() async {
        do {
            async let s: CostSummary = fetch("summary")
            async let d: DailyResponse = fetch("daily")
            summary = try await s
            daily = try await d.daily
            error = nil
        } catch {
            self.error = "Cost service unreachable"
        }
    }

    private func fetch<T: Codable>(_ path: String) async throws -> T {
        let (data, _) = try await URLSession.shared.data(
            from: baseURL.appendingPathComponent(path))
        return try JSONDecoder().decode(T.self, from: data)
    }
}

// MARK: - View

struct CostDashboardView: View {
    @StateObject private var model = CostModel()

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            if let s = model.summary {
                sparkline
                if s.budgetUsd > 0 { budgetBar(s) }
                rungBreakdown(s)
                if s.unpricedCalls > 0 {
                    Label("\(s.unpricedCalls) calls unpriced — update price map",
                          systemImage: "exclamationmark.triangle")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
            } else if let err = model.error {
                Label(err, systemImage: "bolt.slash").foregroundStyle(.secondary)
            } else {
                ProgressView()
            }
        }
        .padding()
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
        .task { await model.refresh() }
        .refreshable { await model.refresh() }
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            VStack(alignment: .leading) {
                Text("Model Spend").font(.headline)
                Text(model.summary?.month ?? "—")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if let s = model.summary {
                VStack(alignment: .trailing) {
                    Text(s.totalUsd, format: .currency(code: "USD"))
                        .font(.title2).bold().monospacedDigit()
                    Text("→ \(s.projectedUsd, format: .currency(code: "USD")) proj.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
        }
    }

    private var sparkline: some View {
        Chart(model.daily) { d in
            BarMark(
                x: .value("Day", String(d.day.suffix(2))),
                y: .value("USD", d.usd)
            )
        }
        .chartYAxis(.hidden)
        .chartXAxis {
            AxisMarks(values: .automatic(desiredCount: 6))
        }
        .frame(height: 72)
    }

    private func budgetBar(_ s: CostSummary) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            ProgressView(value: min(s.budgetUsedPct / 100.0, 1.0))
                .tint(s.budgetUsedPct >= 100 ? .red :
                      s.budgetUsedPct >= 80 ? .orange : .accentColor)
            Text("\(Int(s.budgetUsedPct))% of \(s.budgetUsd, format: .currency(code: "USD")) budget")
                .font(.caption2).foregroundStyle(.secondary)
        }
    }

    private func rungBreakdown(_ s: CostSummary) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(s.byRung.prefix(5)) { r in
                HStack {
                    Text(r.rung).font(.caption)
                    Spacer()
                    Text(r.usd, format: .currency(code: "USD"))
                        .font(.caption).monospacedDigit()
                }
            }
        }
    }
}

#Preview {
    CostDashboardView().frame(width: 340)
}
