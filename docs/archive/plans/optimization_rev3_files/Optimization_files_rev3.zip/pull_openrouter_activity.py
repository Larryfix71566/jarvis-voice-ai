#!/usr/bin/env python3
"""pull_openrouter_activity.py — enrich ledger rows from OpenRouter.

For every openrouter row in the ledger with a gen_id but no reported_cost,
query GET https://openrouter.ai/api/v1/generation?id=<gen_id> and backfill:
  reported_cost, native input/output token counts, cached token count.
Also prints remaining credit balance (GET /api/v1/credits) for the runway
number in the dashboard.

This is also the Phase 0 verifier for assumption A5: after a session with
cache_control breakpoints on routed Claude/Gemini calls, rerun this and
check the cache columns — zeros on second-turn calls mean the discount is
NOT surviving the routed path and those calls belong on the native key.

Key comes from the vault, not .env, per standing policy:
    python -m jarvis.vault get OPENROUTER_API_KEY
is shelled out below; adjust if vault.py exposes a cleaner import.

Endpoint field names drift — this script treats the generation endpoint's
response defensively and logs unknown shapes instead of crashing. If a
field rename breaks backfill, print_raw=True shows what came back.
"""

from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

DB_PATH = Path("data/costs.db")
BASE = "https://openrouter.ai/api/v1"
PRINT_RAW = "--raw" in sys.argv


def get_key() -> str:
    try:
        out = subprocess.run(
            [sys.executable, "-m", "jarvis.vault", "get", "OPENROUTER_API_KEY"],
            capture_output=True, text=True, timeout=15, check=True,
        )
        key = out.stdout.strip()
        if key:
            return key
    except Exception as exc:
        print(f"vault lookup failed ({exc}); falling back to env", file=sys.stderr)
    import os
    key = os.environ.get("OPENROUTER_API_KEY", "")
    if not key:
        sys.exit("No OPENROUTER_API_KEY available (vault or env).")
    return key


def api_get(path: str, key: str) -> dict:
    req = urllib.request.Request(
        f"{BASE}{path}", headers={"Authorization": f"Bearer {key}"}
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode())


def first_present(d: dict, *names, default=None):
    for n in names:
        if n in d and d[n] is not None:
            return d[n]
    return default


def main() -> None:
    key = get_key()

    # runway
    try:
        credits = api_get("/credits", key).get("data", {})
        total = first_present(credits, "total_credits", "total", default=0)
        used = first_present(credits, "total_usage", "usage", default=0)
        print(f"OpenRouter credits: purchased={total} used={used} "
              f"remaining={float(total) - float(used):.2f}")
    except Exception as exc:
        print(f"credits endpoint failed: {exc}", file=sys.stderr)

    if not DB_PATH.exists():
        sys.exit(f"No ledger at {DB_PATH} — run some traffic first.")

    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute(
        "SELECT id, gen_id FROM llm_calls WHERE provider='openrouter'"
        " AND gen_id IS NOT NULL AND reported_cost IS NULL"
    ).fetchall()
    print(f"{len(rows)} openrouter rows to enrich")

    ok = failed = 0
    for row_id, gen_id in rows:
        try:
            data = api_get(f"/generation?id={gen_id}", key).get("data", {})
            if PRINT_RAW:
                print(json.dumps(data, indent=2)[:2000])
            cost = first_present(data, "total_cost", "cost", "usage")
            n_in = first_present(data, "native_tokens_prompt", "tokens_prompt", default=0)
            n_out = first_present(data, "native_tokens_completion", "tokens_completion", default=0)
            cached = first_present(data, "native_tokens_cached", "cached_tokens", default=0)
            conn.execute(
                "UPDATE llm_calls SET reported_cost=?,"
                " input_tokens=CASE WHEN ?>0 THEN ? ELSE input_tokens END,"
                " output_tokens=CASE WHEN ?>0 THEN ? ELSE output_tokens END,"
                " cache_read_tokens=CASE WHEN ?>0 THEN ? ELSE cache_read_tokens END"
                " WHERE id=?",
                (cost, n_in, n_in, n_out, n_out, cached, cached, row_id),
            )
            ok += 1
            time.sleep(0.2)  # be polite; this endpoint is per-generation
        except Exception as exc:
            failed += 1
            print(f"gen {gen_id}: {exc}", file=sys.stderr)
    conn.commit()

    # A5 verdict on what we have
    hit = conn.execute(
        "SELECT COUNT(*) FROM llm_calls WHERE provider='openrouter'"
        " AND cache_read_tokens > 0"
    ).fetchone()[0]
    tot = conn.execute(
        "SELECT COUNT(*) FROM llm_calls WHERE provider='openrouter'"
        " AND reported_cost IS NOT NULL"
    ).fetchone()[0]
    print(f"enriched={ok} failed={failed}; routed calls with cache reads: {hit}/{tot}")
    if tot >= 10 and hit == 0:
        print("A5 WARNING: zero cache reads on routed calls — if breakpoints"
              " are set, the discount is not passing through; move those"
              " calls to the native key.")


if __name__ == "__main__":
    main()
