#!/usr/bin/env python3
"""cost_report.py — Phase 0 baseline report from the ledger.

Usage:
    python scripts/cost_report.py            # current month
    python scripts/cost_report.py 2026-09    # specific month
    python scripts/cost_report.py 2026-09 --json

Reports: total spend, input vs output share, per-rung share, per-model
spend, cache hit rate, run-rate projection, and verdicts on assumptions
A1 (input dominance), A3 (sub-agent share), A5 (routed cache passthrough).
A2 (prefix share) needs prompt-assembly sizes, not the ledger — measured
in Phase 1 when breakpoints go in.

Effective cost per row: reported_cost when present (OpenRouter ground
truth) else computed_cost. Rows with neither are counted and flagged —
an unmapped model must be visible, never silently free.
"""

from __future__ import annotations

import calendar
import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path("data/costs.db")

# Rev 3: the plan's A3 ("sub-agents are ~30% of spend") is about the FIVE
# delegated specialists, not every non-supervisor call. Background
# maintenance and the planner/executor loop are their own buckets — folding
# them into "sub-agent share" would overstate A3 by exactly the rungs Phase
# 2 and Phase 3 target separately. Vocabulary mirrors jarvis/usage_ledger.RUNGS.
BUCKETS = {
    "supervisor": {"supervisor"},
    "sub_agents": {"scheduler", "librarian", "analyst", "systems", "developer"},
    "background": {"memory_merge", "memory_classify", "memory_extraction",
                   "kb_digest", "procedures_describe"},
    "planner":    {"planning", "council"},
    "executor":   {"selfedit_executor", "appbuild_executor"},
    "research":   {"research"},
}


def bucket_of(rung: str) -> str:
    for name, rungs in BUCKETS.items():
        if rung in rungs:
            return name
    return "unknown"


def q(conn, sql, args=()):
    return conn.execute(sql, args).fetchall()


def main() -> None:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    month = args[0] if args else datetime.now(timezone.utc).strftime("%Y-%m")
    as_json = "--json" in sys.argv

    if not DB_PATH.exists():
        sys.exit(f"No ledger at {DB_PATH}")
    conn = sqlite3.connect(DB_PATH)

    eff = "COALESCE(reported_cost, computed_cost)"
    base = f"FROM llm_calls WHERE month = ?"

    total, n_calls = q(conn, f"SELECT COALESCE(SUM({eff}),0), COUNT(*) {base}", (month,))[0]
    unpriced = q(conn, f"SELECT COUNT(*), GROUP_CONCAT(DISTINCT model) {base}"
                       " AND reported_cost IS NULL AND computed_cost IS NULL", (month,))[0]

    # input vs output cost split (computed rows only — needs the price split)
    io = q(conn, f"""
        SELECT model,
               SUM(input_tokens), SUM(output_tokens),
               SUM(cache_write_tokens), SUM(cache_read_tokens),
               COALESCE(SUM({eff}),0)
        {base} GROUP BY model ORDER BY 6 DESC""", (month,))

    rungs = q(conn, f"SELECT rung, COUNT(*), COALESCE(SUM({eff}),0) {base}"
                    " GROUP BY rung ORDER BY 3 DESC", (month,))

    cache = q(conn, f"""
        SELECT provider,
               SUM(CASE WHEN cache_read_tokens > 0 THEN 1 ELSE 0 END),
               COUNT(*)
        {base} GROUP BY provider""", (month,))

    days = q(conn, f"SELECT substr(ts,1,10), COALESCE(SUM({eff}),0) {base}"
                   " GROUP BY 1 ORDER BY 1", (month,))

    # projection
    year, mon = map(int, month.split("-"))
    days_in_month = calendar.monthrange(year, mon)[1]
    days_elapsed = len(days) or 1
    projected = (total / days_elapsed) * days_in_month if total else 0.0

    by_bucket: dict[str, float] = {}
    for r, _, c in rungs:
        by_bucket[bucket_of(r)] = by_bucket.get(bucket_of(r), 0.0) + c
    sub_cost = by_bucket.get("sub_agents", 0.0)
    sub_share = (sub_cost / total) if total else 0.0

    tin = sum(r[1] for r in io)
    tout = sum(r[2] for r in io)
    tcache_r = sum(r[4] for r in io)

    report = {
        "month": month,
        "calls": n_calls,
        "total_cost_usd": round(total, 4),
        "projected_month_end_usd": round(projected, 2),
        "unpriced_calls": {"count": unpriced[0], "models": unpriced[1]},
        "tokens": {"input_uncached": tin, "output": tout, "cache_read": tcache_r},
        "per_rung": [{"rung": r, "calls": c, "cost": round(v, 4)} for r, c, v in rungs],
        "per_bucket": {k: round(v, 4) for k, v in sorted(by_bucket.items(), key=lambda kv: -kv[1])},
        "per_model": [
            {"model": m, "in": i, "out": o, "cache_w": cw, "cache_r": cr,
             "cost": round(v, 4)} for m, i, o, cw, cr, v in io
        ],
        "cache_hit_calls_by_provider": [
            {"provider": p, "with_cache_reads": h, "calls": t} for p, h, t in cache
        ],
        "daily": [{"day": d, "cost": round(v, 4)} for d, v in days],
        "assumption_verdicts": {},
    }

    # A1: input dominance — token-based proxy; exact split needs price map rows
    if tin + tout:
        report["assumption_verdicts"]["A1_input_token_share"] = round(
            (tin + tcache_r) / (tin + tcache_r + tout), 3)
    # A3: sub-agent share of spend — the five specialists only (see BUCKETS)
    report["assumption_verdicts"]["A3_subagent_cost_share"] = round(sub_share, 3)
    report["assumption_verdicts"]["A3_non_supervisor_share"] = round(
        (total - by_bucket.get("supervisor", 0.0)) / total, 3) if total else 0.0
    # A5: routed cache passthrough
    for p, h, t in cache:
        if p == "openrouter" and t >= 10:
            report["assumption_verdicts"]["A5_routed_cache_working"] = h > 0

    if as_json:
        print(json.dumps(report, indent=2))
        return

    print(f"=== Mortimer cost report — {month} ===")
    print(f"calls: {n_calls}   total: ${total:.2f}   projected month-end: ${projected:.2f}")
    if unpriced[0]:
        print(f"!! {unpriced[0]} calls have NO cost (unmapped models: {unpriced[1]})"
              f" — fill config/model_prices.yaml")
    print(f"tokens: in(uncached)={tin:,}  cache_read={tcache_r:,}  out={tout:,}")
    print("\nby rung:")
    for r, c, v in rungs:
        pct = (v / total * 100) if total else 0
        print(f"  {r:<14} {c:>6} calls  ${v:>8.2f}  {pct:5.1f}%")
    print("\nby bucket:")
    for k, v in sorted(by_bucket.items(), key=lambda kv: -kv[1]):
        pct = (v / total * 100) if total else 0
        print(f"  {k:<14} ${v:>8.2f}  {pct:5.1f}%")
    print("\nby model:")
    for m, i, o, cw, cr, v in io:
        print(f"  {m:<44} ${v:>8.2f}  cache_r={cr:,}")
    print("\ncache reads by provider:")
    for p, h, t in cache:
        print(f"  {p:<12} {h}/{t} calls had cache reads")
    print("\nverdicts:", json.dumps(report["assumption_verdicts"]))


if __name__ == "__main__":
    main()
