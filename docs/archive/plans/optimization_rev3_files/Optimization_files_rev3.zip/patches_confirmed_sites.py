# Patches for the six confirmed call sites. All six build their client the
# same way (settings.openai_api_key / settings.openai_base_url — currently
# Anthropic Haiku via the OPENAI_*-named-but-Anthropic deployment quirk) and
# call chat.completions.create with the response bound to a local
# `response` variable. Add the import once per file, then one line after
# each response = await client.chat.completions.create(...) call.

# ============================================================
# jarvis/agents/supervisor.py  (~line 128, in Orchestrator.chat)
# ============================================================
"""
Add near the top of the file:
    from jarvis.usage_ledger import record_completion, provider_from_base_url

After:
    response = await self._client.chat.completions.create(
        model=self._settings.openai_model,
        ...
    )
Add:
    try:
        record_completion(
            rung="supervisor",
            provider=provider_from_base_url(str(self._client.base_url)),
            model=self._settings.openai_model,
            response=response,
            session_id=self.session_id,
        )
    except Exception:
        pass  # cost logging must never break a live voice turn
"""

# ============================================================
# jarvis/memory_sweep.py  — TWO sites
# ============================================================
"""
Add near the top of the file:
    from jarvis.usage_ledger import record_completion, provider_from_base_url

Site 1 (~line 362, inside _merge_cluster — rung="memory_merge"):
    response = await client.chat.completions.create(
        model=model,
        ...
    )
    try:
        record_completion(
            rung="memory_merge",
            provider=provider_from_base_url(str(client.base_url)),
            model=model,
            response=response,
        )
    except Exception:
        pass

Site 2 (~line 649, inside _classify_batch — rung="memory_classify"):
    response = await client.chat.completions.create(
        model=settings.openai_model,
        ...
    )
    try:
        record_completion(
            rung="memory_classify",
            provider=provider_from_base_url(str(client.base_url)),
            model=settings.openai_model,
            response=response,
        )
    except Exception:
        pass

Note: neither site currently has an obvious session_id in scope (these are
batch/background jobs, not a live turn) — omit session_id here; the ledger
column is nullable and per-rung/per-month aggregation doesn't need it.
"""

# ============================================================
# jarvis/memory.py  (~line 868, inside update_memory_from_session
#                     — rung="memory_extraction")
# ============================================================
"""
Add near the top of the file:
    from jarvis.usage_ledger import record_completion, provider_from_base_url

After:
    response = await client.chat.completions.create(
        model=settings.openai_model,
        ...
    )
Add:
    try:
        record_completion(
            rung="memory_extraction",
            provider=provider_from_base_url(str(client.base_url)),
            model=settings.openai_model,
            response=response,
        )
    except Exception:
        pass

This is the exact call site Phase 2 (plan doc) eventually restructures
into the async post-turn extraction worker — tagging it now under
"memory_extraction" gives you a real before/after number for that phase,
not just a code-quality argument for making the change.
"""

# ============================================================
# jarvis/kb_digest.py  (~line 117, inside write_session_digest
#                        — rung="kb_digest")
# ============================================================
"""
Add near the top of the file:
    from jarvis.usage_ledger import record_completion, provider_from_base_url

After:
    response = await client.chat.completions.create(
        model=settings.openai_model,
        ...
    )
Add:
    try:
        record_completion(
            rung="kb_digest",
            provider=provider_from_base_url(str(client.base_url)),
            model=settings.openai_model,
            response=response,
        )
    except Exception:
        pass
"""

# ============================================================
# jarvis/procedures.py  (~line 361, inside _describe_procedure
#                         — rung="procedures_describe")
# ============================================================
"""
Add near the top of the file:
    from jarvis.usage_ledger import record_completion, provider_from_base_url

After:
    response = await client.chat.completions.create(
        model=settings.openai_model,
        ...
    )
Add:
    try:
        record_completion(
            rung="procedures_describe",
            provider=provider_from_base_url(str(client.base_url)),
            model=settings.openai_model,
            response=response,
        )
    except Exception:
        pass
"""

# ============================================================
# jarvis/agents/base.py  (~line 576, in SubAgent._loop)
# Covers FIVE rungs at once: scheduler, librarian, analyst, systems,
# developer — each is a SubAgent instance; self.name is already the
# config's `name:` field (confirmed via __init__: self.name = name),
# so no new attribute is needed.
# ============================================================
"""
Add near the top of the file:
    from jarvis.usage_ledger import record_completion, provider_from_base_url

Confirmed exact code (lines 576-580):
    response = await client.chat.completions.create(
        model=model,
        messages=messages,
        **tools_kwarg,
    )
Add immediately after:
    try:
        record_completion(
            rung=self.name,
            provider=provider_from_base_url(str(client.base_url)),
            model=model,
            response=response,
        )
    except Exception:
        pass  # cost logging must never break a live tool-calling loop

Note: `client` and `model` here are the LOCAL run_client/run_model bound
at the top of run() (line 430: `run_client, run_model = self._client,
self._model`) and threaded into _loop's params — NOT necessarily
self._client/self._model directly (the function's own comment at line
484 warns _loop uses these locals, never self._client/self._model,
specifically to support a test seam). Using the local `client`/`model`
names already in scope at line 576 is correct and matches that seam.

This single hook is why developer's claude-opus rows will show
provider="anthropic" via provider_from_base_url — same detection as the
default path, since claude-opus's base_url in upgrade_models.yaml is
also api.anthropic.com. That's correct: it really is a different model
(claude-opus-5 vs claude-haiku-4-5), same vendor route.
"""

# ============================================================
# jarvis/council/council.py  (~line 235, inside _call_profile._sync_call)
# Dynamic per-member provider/model — each council call resolves a
# DIFFERENT profile from upgrade_models.yaml (kimi, claude-opus,
# or-gpt-5.1, etc.), so provider/model come from the profile dict
# already in scope here, not from settings.
# ============================================================
"""
Add near the top of the file:
    from jarvis.usage_ledger import record_completion

Confirmed exact code:
    response = client.chat.completions.create(**request)
    content = response.choices[0].message.content or ""
    usage_obj = getattr(response, "usage", None)
Add immediately after `response = client.chat.completions.create(**request)`,
BEFORE the manual usage_obj parsing (record_completion parses the full
response itself — no need to reuse the stripped-down usage dict this
function builds for its own return value):
    try:
        record_completion(
            rung="council",
            provider=profile.get("provider", "unknown"),
            model=profile.get("identity", profile.get("model", "unknown")),
            response=response,
        )
    except Exception:
        pass

provider and identity are read straight from the profile dict — upgrade_
models.yaml already carries both explicitly (comments there: "identity...
the canonical vendor/model string... distinct from `model`") specifically
to disambiguate one underlying model reached two different ways. Using
them here means council's price-map keys (e.g. "anthropic/claude-opus-5",
"openrouter/openai/gpt-5.1") come directly from the same source of truth
the council's own self-judging guarantee relies on — no separate mapping
to keep in sync.

_sync_call is a plain sync function (called via a thread executor from
the async _call_profile) — record_call's threading.Lock already makes
this safe to call from a worker thread; no additional guard needed.
"""

# ============================================================
# EFFORT WIRING (added 2026-09-01) — jarvis/effort.py is a new file;
# these additions ride the SAME call sites patched above.
# ============================================================
"""
config/agents.yaml — add per-agent effort (same pattern as timeout_s).
Starting defaults, to be revisited once the baseline report shows
thinking-token spend per rung:

  - name: scheduler
    effort: low          # trivial dispatch — time/date/reminders
  - name: librarian
    effort: medium       # recall + review resolution
  - name: analyst
    effort: medium       # web lookups; the ITERATIONS budget, not
                         # reasoning depth, was its measured bottleneck
  - name: systems
    effort: low          # reads counters, formats them
  - name: developer
    # no effort key — leave provider default (high); reasoning IS the job

jarvis/agents/base.py — SubAgent.__init__ gains `effort: str | None = None`
(threaded from load_sub_agents like timeout_s); store `self._effort = effort`.
At the line-576 call site, extend the create call:

    from jarvis.effort import extra_body_for
    from jarvis.usage_ledger import provider_from_base_url

    _eb = extra_body_for(self.name,
                         provider_from_base_url(str(client.base_url)),
                         self._effort)
    response = await client.chat.completions.create(
        model=model,
        messages=messages,
        **tools_kwarg,
        **({"extra_body": _eb} if _eb else {}),
    )

jarvis/agents/supervisor.py, memory_sweep.py (both sites), memory.py,
kb_digest.py, procedures.py — same two lines before each create call,
with the rung string instead of self.name and no explicit level (these
resolve via env: JARVIS_EFFORT_SUPERVISOR, JARVIS_EFFORT_MEMORY_MERGE,
JARVIS_EFFORT_MEMORY_CLASSIFY, JARVIS_EFFORT_MEMORY_EXTRACTION,
JARVIS_EFFORT_KB_DIGEST, JARVIS_EFFORT_PROCEDURES_DESCRIBE, or
JARVIS_EFFORT_DEFAULT). Suggested .env starting point:

    JARVIS_EFFORT_SUPERVISOR=medium      # voice dispatcher; latency-bound
    JARVIS_EFFORT_MEMORY_MERGE=low
    JARVIS_EFFORT_MEMORY_CLASSIFY=low
    JARVIS_EFFORT_MEMORY_EXTRACTION=medium
    JARVIS_EFFORT_KB_DIGEST=medium
    JARVIS_EFFORT_PROCEDURES_DESCRIBE=low

jarvis/council/council.py — per-profile: add `effort:` to individual
profiles in config/upgrade_models.yaml where wanted (economy-tier
proposers are the candidates; leave frontier judges unset), and in
_call_profile._sync_call:

    from jarvis.effort import extra_body_for
    _eb = extra_body_for("council", profile.get("provider", ""),
                         profile.get("effort"))
    if _eb:
        request.update(extra_body=_eb) if False else request  # NOTE:
    # council builds a raw request dict passed as **request to a sync
    # OpenAI client — extra_body is an SDK kwarg, so add it to the dict:
    if _eb:
        request["extra_body"] = _eb
    response = client.chat.completions.create(**request)

ROLLOUT RULE (cache interaction): pick each rung's effort ONCE and keep
it constant — changing effort mid-session invalidates the cached prompt
prefix per Anthropic's docs. Verify the extra_body shape with ONE test
call per provider (watch for HTTP 400) before setting env vars for all
rungs; JARVIS_EFFORT_DEFAULT stays UNSET until that check passes.
"""

# ============================================================
# PHASE 0b FIXES (root-caused 2026-09-01) — three small repo edits,
# independent of the cost/effort wiring above; apply first.
# ============================================================
"""
FIX 1 — config/upgrade_models.yaml, kimi-k3 profile, add:

    timeout_s: 240
    # 2026-09-01 — K3 is always-on thinking: probed 39 completion tokens
    # to answer "OK", 36s on a 2.3K-token judge task; real judge
    # workloads (8-15K tokens) project 90-180s+ against the 120s
    # COUNCIL_MEMBER_TIMEOUT_S. Round e48cfbe1: all four K3 judge calls
    # timed out (asyncio.TimeoutError stringifies empty, hence the blank
    # abstain reasons). Per-profile rope, not a global raise, so other
    # members don't inflate every round's wall time.

FIX 2 — jarvis/council/council.py, line ~249. Confirmed current code:

    return await asyncio.wait_for(asyncio.to_thread(_sync_call), timeout=timeout_s)

Replace with:

    effective = max(timeout_s, float(profile.get("timeout_s", 0)))
    return await asyncio.wait_for(asyncio.to_thread(_sync_call), timeout=effective)

max() deliberately: a profile can buy itself MORE time than the caller's
floor, never less — the planning pathway's PLANNING_MEMBER_TIMEOUT_S=300
is untouched, and no profile can shrink below a caller's floor.

FIX 3 — config/upgrade_models.yaml, top of file:

    default: kimi-k3    -->    default: claude-fable-5

    # 2026-09-01 — kimi-k3 retired as the self-edit planner default:
    # always-on thinking latency (see timeout_s note on its profile)
    # made the default planner the slowest thinker in the registry, and
    # frontier-for-planning is now the standing policy (plan Rev 2,
    # Phase 3). K3 remains in the registry and the council pool.

Accepted trade for FIX 1: escalation rounds that include K3 as judge can
run ~4 min wall time. Revisit (pull K3 from the judge tier instead) if
councils ever move into the interactive loop.
"""

# ============================================================
# REV 3 (2026-09-01, conflict resolution) — TWO MORE SITES + a rung fix.
# Total is now 13 patched call sites, not 11.
# ============================================================
"""
WHY: the readiness checklist deferred jarvis/agents/upgrade_agent.py:469
citing "double-count risk with the base.py hook". That risk does not
exist: base.py's hook runs in the BOT process (the developer SubAgent's
own dispatch calls); upgrade_agent.py:469 runs in the ADMIN SIDECAR
process (the self-edit / app-build edit loop's planner-model calls). They
are different processes making different completions. Leaving :469
unpatched would have left the EXECUTOR rung — the one Phase 0b is about
to move onto claude-fable-5, the priciest profile in the registry — as
the single rung with no ledger row. Patch it in the same commit as the
other twelve.

SITE 12 — jarvis/agents/upgrade_agent.py, line 469. Confirmed current code
(inside the failover-wrapped completion helper):

            try:
                return self._client.chat.completions.create(**request)
            except Exception as exc:  # noqa: BLE001 — classified immediately below

Replace the `return` line with:

            try:
                response = self._client.chat.completions.create(**request)
                try:
                    record_completion(
                        rung=f"{self._council_workflow}_executor",   # selfedit_executor | appbuild_executor
                        provider=provider_from_base_url(str(self._client.base_url)),
                        model=request.get("model", self.model),
                        response=response,
                    )
                except Exception:
                    pass
                return response
            except Exception as exc:  # noqa: BLE001 — classified immediately below

`self._council_workflow` is already set in __init__ (line 315; "selfedit"
by default, "appbuild" for AppBuildAgent via its super().__init__ call at
line 954), so AppBuildAgent gets its own rung for free with zero code in
the subclass. `request["model"]` is the wire model string actually sent
(it is rebuilt by the failover path when the client is swapped, which is
exactly why we read it from the request rather than a cached attribute).
Add the two imports at the top of the file.

SITE 13 + RUNG FIX — jarvis/council/council.py `_call_profile` is called
from FOUR distinct workflows, and the Rev 2 patch labelled all of them
"council":
    council.py:367 / :448        convene()          -> escalation rounds (E1/E2/E3)
    council.py (draft_candidates) -> planning rounds (plan documents)
    admin/server.py:659           -> single-mode plan author
    admin/server.py:440           -> site-research comparison writer
Three of those are not the council. Fix at the source: give _call_profile
a keyword parameter and thread it.

    async def _call_profile(
        profile: dict[str, Any], system_prompt: str, user_content: str,
        timeout_s: float, *, rung: str = "council",
    ) -> tuple[str, dict[str, int] | None]:

and use `rung=rung` in the record_completion call inside _sync_call
(closure — `rung` is visible there). Then:

    - convene()'s proposer/judge helpers: pass nothing (default "council").
    - _draft_candidates_inner's proposer/judge calls: pass rung="planning"
      through the same helpers (add a `rung: str = "council"` kwarg to
      each helper and forward it — two small signature additions).
    - admin/server.py:659 (single-mode plan author): rung="planning".
    - admin/server.py:440 (_run_research_job):          rung="research".

`_call_profile` is a private module function with exactly these callers
(grep-confirmed 2026-09-01), so a keyword-only addition with a default
breaks none of them and tests/unit/test_council*.py keep passing unchanged.
"""
