"""effort.py — per-rung effort level resolution for Mortimer.

One lever, one rule: effort is a STATIC per-rung setting, never a per-call
decision. Rationale (Rev 3 wording): the cache-invalidation interaction
between effort and prompt caching is documented for the native Messages
API's thinking parameters; whether the same holds for the effort field as
sent through the OpenAI-compatible endpoint this repo uses is NOT
separately confirmed — it is the same class of inference as the key shape
below. Holding effort constant per rung is therefore the SAFE default (it
cannot hurt the cache), not a proven requirement. The Phase 1b gate checks
both halves in one session: (1) the extra_body shape is accepted, and (2)
toggling effort between two otherwise-identical turns does/does not drop
cache_read_tokens to zero. If (2) shows no cache effect, per-call effort
becomes an allowed future lever; until then, static.

Resolution order (first hit wins):
  1. explicit value passed by the caller (agents.yaml `effort:` for
     SubAgents, profile `effort:` for council members)
  2. JARVIS_EFFORT_<RUNG> env var (rung uppercased, e.g.
     JARVIS_EFFORT_MEMORY_MERGE=low) — the home for the loose background
     rungs (memory_*, kb_digest, procedures_describe, supervisor)
  3. JARVIS_EFFORT_DEFAULT env var
  4. None — send nothing, let the provider default apply (currently
     'high' on Claude 5-class models)

Values: low | medium | high | xhigh | max (Anthropic ladder). OpenAI-
family models reached via OpenRouter use reasoning_effort with a similar
ladder — extra_body_for() emits the right key shape per provider.

VERIFY BEFORE TRUSTING: the exact extra_body key for effort through
Anthropic's OpenAI-compatible endpoint ({"output_config": {"effort": ...}})
is inferred from the documented extra_body pattern for thinking/
budget_tokens — confirmed shape for thinking, inferred for effort. Run one
test call per provider with JARVIS_DEBUG_USAGE_LEDGER=1 and confirm the
response changes (and no 400) before rolling out beyond one rung.
"""

from __future__ import annotations

import os
from typing import Any, Optional

_VALID = {"low", "medium", "high", "xhigh", "max"}

# Providers whose effort control is OpenAI's reasoning_effort field.
# Anthropic (direct compat endpoint) uses output_config.effort instead.
# Moonshot kimi-k3 is "always-on thinking" with no known effort lever —
# emit nothing for it rather than guessing a parameter it may reject.
_OPENAI_STYLE = {"openai", "openrouter"}
_ANTHROPIC_STYLE = {"anthropic"}


def resolve_effort(rung: str, explicit: Optional[str] = None) -> Optional[str]:
    """Resolve the effort level for a rung. Returns None when nothing is
    configured — callers then send no effort field at all."""
    for candidate in (
        explicit,
        os.environ.get(f"JARVIS_EFFORT_{rung.upper().replace('-', '_')}"),
        os.environ.get("JARVIS_EFFORT_DEFAULT"),
    ):
        if candidate:
            value = candidate.strip().lower()
            if value in _VALID:
                return value
            import sys
            print(f"effort: ignoring invalid level {candidate!r} for rung "
                  f"{rung} (valid: {sorted(_VALID)})", file=sys.stderr)
    return None


def extra_body_for(rung: str,
                   provider: str,
                   explicit: Optional[str] = None) -> dict[str, Any]:
    """Build the extra_body fragment for chat.completions.create, or {}
    when no effort is configured or the provider has no known lever.

    Usage at a call site:
        eb = extra_body_for(self.name, provider_from_base_url(str(client.base_url)))
        response = await client.chat.completions.create(
            model=model, messages=messages, **tools_kwarg,
            **({"extra_body": eb} if eb else {}),
        )
    """
    level = resolve_effort(rung, explicit)
    if not level:
        return {}
    p = (provider or "").lower()
    if p in _ANTHROPIC_STYLE:
        return {"output_config": {"effort": level}}
    if p in _OPENAI_STYLE:
        # OpenAI ladder is minimal/low/medium/high — clamp the Anthropic-
        # only levels down so a shared config value can't 400 an OpenAI-
        # family call routed via OpenRouter.
        clamped = {"xhigh": "high", "max": "high"}.get(level, level)
        return {"reasoning_effort": clamped}
    return {}  # moonshot / unknown: no known lever, send nothing
